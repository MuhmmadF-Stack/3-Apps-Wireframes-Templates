# Mobile App Prototype Templates

A collection of three fully interactive, high-fidelity mobile app prototypes — **Daily Dish** (food delivery), **Stride** (fitness tracking) and **Pocket** (personal budgeting). Each app is built as a self-contained HTML file with no build step, no dependencies to install and no backend. Open a file in any modern browser and every screen, flow and state works out of the box.

The templates are intended as a starting point for product designers, founders and front-end developers who need a realistic, clickable prototype for user testing, stakeholder demos, pitch decks or as a reference implementation for a production build.

---

## Contents

| File | Description |
|---|---|
| `Index.dc.html` | Landing page linking to all three prototypes |
| `Daily Dish.dc.html` | Food delivery app |
| `Stride.dc.html` | Fitness tracking app |
| `Pocket.dc.html` | Personal budgeting app |
| `support.js` | Lightweight runtime required by the `.dc.html` files |

---

## The apps

### Daily Dish — Food delivery
A complete ordering journey from discovery to doorstep.

- **Restaurant discovery** with live search across restaurants and dishes, cuisine filters, sorting (top rated, fastest, lowest fee) and delivery-time / fee filters
- **Favorites** — save restaurants from any screen; a dedicated Favorites tab
- **Restaurant menu** with section navigation and in-menu search
- **Item customization** with required and optional modifier groups, selection limits, special instructions and quantity, with live price calculation
- **Cart and checkout** — edit or remove lines, standard vs. priority delivery, editable address, payment method selection
- **Promo codes** — `DISH10` (10% off), `FREEDEL` (free delivery), `WELCOME5` ($5 off orders of $15+), with validation and error states
- **Live order tracking** — animated courier progress through Confirmed → Preparing → On the way → Delivered, with cancellation available before pickup
- **Order history** with one-tap reorder
- Single-restaurant cart rule with a confirmation prompt when switching restaurants

### Stride — Fitness tracking
A workout companion built around a weekly goal.

- **Daily dashboard** — weekly goal progress, minutes and calories, a 7-day activity chart and a recommended workout
- **Workout discovery** — search by workout or exercise name, type filters (Strength, Cardio, Mobility, Saved), duration and level filters
- **Workout detail** — structure breakdown (warm-up, rounds, cool-down) and full move list; save workouts for later
- **Active workout** — a real interval timer with work / rest phases, progress ring, segmented session bar, pause / resume, skip forward / back and optional audio cues
- **End early** — save a partial session or discard it
- **Workout summary** — minutes, calories, average heart rate, weekly goal progress and an effort rating
- **Progress** — weekly minutes chart and a complete workout history
- **Profile** — adjustable weekly goal, sound and appearance settings
- A **timer speed** setting (1×, 5×, 20×) for faster demos

### Pocket — Personal budgeting
A calm, editorial take on monthly budgeting.

- **Financial overview** — remaining monthly budget, spending progress, income and top categories
- **Transactions** — grouped by day, searchable by merchant, category or note, with All / Expenses / Income views
- **Transaction detail** with delete confirmation; budgets recalculate immediately
- **Add expense** — validated amount and merchant fields, category picker, date, account and note, with a live preview of the impact on the category budget
- **Review step** — shows the category budget after the new expense before anything is saved
- **Saved confirmation** with reference number and updated balances
- **Budgets** — all eight categories, with over-budget and near-limit warnings and adjustable monthly limits
- **Month switcher** (September / October 2026 sample data)

---

## Shared features

- **Light and dark mode** in every app, toggled from the header or the in-app settings screen
- **Distinct visual identity per app** — each prototype has its own typeface pairing, accent colour and tone
- **Realistic sample data** that stays internally consistent: totals, budgets and progress are calculated, not hard-coded
- **Empty, error and edge states** — empty cart, no search results, no favorites, invalid promo codes, form validation
- **Device-accurate layout** — designed in a 390 × 844 pt iPhone frame with 44 pt minimum touch targets

---

## Getting started

```bash
git clone https://github.com/<your-username>/<repo-name>.git
cd <repo-name>
```

Then either open `Index.dc.html` directly in your browser, or serve the folder locally for the most reliable results:

```bash
npx serve .
# or
python3 -m http.server 8000
```

and visit `http://localhost:8000/Index.dc.html`.

> Keep `support.js` in the same folder as the `.dc.html` files — every prototype loads it.

### Publishing with GitHub Pages
1. Push the repository to GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your prototypes will be available at `https://<your-username>.github.io/<repo-name>/Index.dc.html`.

---

## Customizing

Each app is a single file containing three parts:

1. **Markup** — the screens, written as HTML with inline styles
2. **Logic** — a `Component` class that holds state, sample data and interactions
3. **Theme** — CSS custom properties (`--accent`, `--bg`, `--ink`, etc.) defined once at the top for light and dark modes

Common changes:

- **Brand colour** — edit `--accent` in the `<style>` block near the top of the file
- **Sample data** — restaurants and menus (`this.R`), workouts (`this.W`) and transactions (`seed()`) are plain JavaScript arrays inside the logic class
- **Promo codes** — edit `this.PROMOS` in `Daily Dish.dc.html`
- **Budget categories and limits** — edit `this.CATS` in `Pocket.dc.html`

Image areas use labelled placeholders (for example *RESTAURANT COVER IMAGE*) so they can be swapped for real photography.

---

## Browser support

Recent versions of Chrome, Edge, Safari and Firefox. The prototypes use modern CSS such as `oklch()` colours and `conic-gradient()`.

---

## Notes

- These are **front-end prototypes**. No real payments, accounts, network requests or location tracking take place; all data lives in memory and resets on reload.
- Fonts are loaded from Google Fonts: Bricolage Grotesque, Figtree, Archivo, Newsreader, IBM Plex Sans and the JetBrains Mono / IBM Plex Mono families.

---

## License

Released under the MIT License. You are free to use, modify and distribute these templates in personal and commercial projects.
